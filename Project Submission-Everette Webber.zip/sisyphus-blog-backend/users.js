// users.js
const users = [
    { id: 1, username: 'matt', password: 'password123', role: 'developer' },
    { id: 2, username: 'jocelyn', password: 'password123', role: 'developer' },
    { id: 3, username: 'regularuser', password: 'userpassword', role: 'user' }
  ];
  
  module.exports = users; // Export the user data
  